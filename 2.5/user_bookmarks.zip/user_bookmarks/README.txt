User Bookmarks Block for Moodle 2.4+ (Tested up to 2.5.1):

Suggestions for improvement are welcome on the tracker (tracker.moodle.org).

The User Bookmarks block was created using Admin Bookmarks block. User Bookmarks allows all user types to bookmark any moodle page.

For Additional Languages:
Create a new Folder and language File based on lang/en/block_user_bookmars.php,
(for Example lang/fr/block_user_bookmars.php for French)

And if it's good post it to:
https://moodle.org/plugins/view.php?plugin=block_user_bookmarks


Installation:

01) Copy the files into the \blocks folder so that you have a \blocks\user_bookmarks folder.
02) Go to the \admin page and allow the block to be installed
03) go to home page or any page
04) Turn editing on in any home or course page.
05) Add the block to the page.
06) click the config button for the block to edit more options

